<?php
/*

Starbucks Account Creator V1.0
FB: https://fb.com/sayarejaa
IG: @sayareja

11:13 PM 9/20/2022

Special Thanks: SGBTeam

*/
include("config.php");

echo "

 _____  _                   _____                    _               
/  ___|| |                 /  __ \                  | |              
\ `--. | |__   _   _ __  __| /  \/ _ __  ___   __ _ | |_  ___   _ __ 
 `--. \| '_ \ | | | |\ \/ /| |    | '__|/ _ \ / _` || __|/ _ \ | '__|
/\__/ /| |_) || |_| | >  < | \__/\| |  |  __/| (_| || |_| (_) || |   
\____/ |_.__/  \__,_|/_/\_\ \____/|_|   \___| \__,_| \__|\___/ |_|   
                                                        Version: V1.0 
                                                        By: SayaReja
";

// Nama 1
$first_name = getName();
$last_name = getName();
$get_imel = anjinglah("https://www.1secmail.com/api/v1/?action=genRandomMailbox&count=1");
$imelna = json_decode($get_imel,true);
$dptimel = $imelna['0'];

echo "[ ".date('d-m-Y H:i:s')." ] Phone Number : +62";
$phone_number = trim(fgets(STDIN));
$kirim_otp = sendOTP($phone_number);
if(strpos($kirim_otp,'"status":200')){
echo "[ ".date('d-m-Y H:i:s')." ] Otp Successfully Send To Your Number\n";
sleep(2);
echo "[ ".date('d-m-Y H:i:s')." ] Enter OTP : ";
$entered_top = trim(fgets(STDIN));

// VALIDATING OTP //
$isvalid = validOTP($entered_top,$phone_number);
if(strpos($isvalid,'Verification code valid')){
$registered = register($dptimel,$phone_number,$entered_top,$first_name,$last_name);
if(strpos($registered,'Registration Success')){
echo "
==============================
Account Created Successfully
Name: $first_name $last_name
Email: $dptimel
Password: Zxcv2702#
MailAccess: https://server.xfatih.com/sbux/mail.php?email=$dptimel
===============================
";
}else{
echo $registered;die;
}
}else{
	echo "Verification Code invalid ..!! TRY AGAIN BRUH";die;
}
}else{
	echo "Failed Send OTP,RETRY AFTER 30 Seconds";die;
}