<?php

/*

Starbucks Account Creator V1.0
FB: https://fb.com/sayarejaa
IG: @sayareja

11:13 PM 9/20/2022

Special Thanks: SGBTeam

*/

function sendOTP($pnum){
$url = "https://api2.sbuxcard.com//v1/auth/generate-sms-otp";
$data = '{"phoneNumber":"'.$pnum.'"}';
$milliseconds = floor(microtime(true) * 1000);

$curl = curl_init($url);
curl_setopt($curl, CURLOPT_URL, $url);
curl_setopt($curl, CURLOPT_POST, true);
curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);

$headers = array(
   "user-agent: Dart/2.17 (dart:io)",
   "x-signature: 1663685232458:e75c544db1782228865f27a2f1fed11acaad1308587538bdf7546ac104fe4d3c",
   "accept-language: en",
   //"accept-encoding: gzip",
   "content-length: ".strlen($data),
   "host: api2.sbuxcard.com",
   "Content-Type: application/json",
);
curl_setopt($curl, CURLOPT_HTTPHEADER, $headers);


curl_setopt($curl, CURLOPT_POSTFIELDS, $data);

//for debug only!
curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, false);
curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);

$resp = curl_exec($curl);
curl_close($curl);
return $resp;

}

function validOTP($otpnya,$pnumber){
$data = '{"otp":"'.$otpnya.'","phoneNumber":"'.$pnumber.'"}';

$url = "https://api2.sbuxcard.com//v1/auth/validate-sms-otp";

$curl = curl_init($url);
curl_setopt($curl, CURLOPT_URL, $url);
curl_setopt($curl, CURLOPT_POST, true);
curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);

$headers = array(
   "user-agent: Dart/2.17 (dart:io)",
   "x-signature: 1663685259200:1e4bc50096b733dab0ff47df665c4d0f571dc8eb8f2728b9846473acf160170b",
   "accept-language: en",
   //"accept-encoding: gzip",
   "content-length: ".strlen($data),
   "host: api2.sbuxcard.com",
   "Content-Type: application/json",
);
curl_setopt($curl, CURLOPT_HTTPHEADER, $headers);

curl_setopt($curl, CURLOPT_POSTFIELDS, $data);

//for debug only!
curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, false);
curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);

$resp = curl_exec($curl);
curl_close($curl);
return $resp;

}

function register($email,$phone,$otpku,$nama1,$nama2){
$url = "https://api2.sbuxcard.com//v1/customer/registration";

$data = '{"email":"'.$email.'","password":"Zxcv2702#","external_id":null,"first_name":"'.$nama1.'","last_name":"'.$nama2.'","dob":"2000-9-21","fav_beverage":"double chocolate greentea","direct_marcomm":true,"phone_number":"'.$phone.'","referralCode":"REZAR-E59DF8","otp":"'.$otpku.'"}';


$curl = curl_init($url);
curl_setopt($curl, CURLOPT_URL, $url);
curl_setopt($curl, CURLOPT_POST, true);
curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);

$headers = array(
   "user-agent: Dart/2.17 (dart:io)",
   "x-signature: 1663685319338:0b8592b21c9b6448e3fa674f206ecd9750ed77e2b91d09ad2c970a6b2c79dba7",
   "accept-language: en",
   //"accept-encoding: gzip",
   "content-length: ".strlen($data),
   "host: api2.sbuxcard.com",
   "Content-Type: application/json",
);
curl_setopt($curl, CURLOPT_HTTPHEADER, $headers);

curl_setopt($curl, CURLOPT_POSTFIELDS, $data);

//for debug only!
curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, false);
curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);

$resp = curl_exec($curl);
curl_close($curl);
return $resp;

}

function getName()
    {
        $r = anjinglah('https://www.random-name-generator.com/indonesia?gender=&n=1&s='.rand(111,999));
        $namenya = get_between($r,'<div class="col-sm-12 mb-3" id="','-');
$nama_indo = preg_replace('/s+/', '', $namenya);
       return ucfirst($nama_indo);
    }
	
	function get_between($string, $start, $end) {
    $string = " ".$string;
    $ini = strpos($string,$start);
    if ($ini == 0) return "";
    $ini += strlen($start);
    $len = strpos($string,$end,$ini) - $ini;
    return substr($string,$ini,$len);
}

function anjinglah($Url) {
    if (!function_exists('curl_init')){ 
        die('CURL is not installed!');
    }
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $Url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    $output = curl_exec($ch);
    curl_close($ch);
    return $output;
}